package com.example.beststore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeststoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeststoreApplication.class, args);
	}

}
